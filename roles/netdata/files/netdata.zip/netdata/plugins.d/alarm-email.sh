#!/usr/bin/env bash

# OBSOLETE - REPLACED WITH
# alarm-notify.sh

${0/alarm-email.sh/alarm-notify.sh} "${@}"
