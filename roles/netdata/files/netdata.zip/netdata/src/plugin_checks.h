#ifndef NETDATA_PLUGIN_CHECKS_H
#define NETDATA_PLUGIN_CHECKS_H 1

void *checks_main(void *ptr);

#endif /* NETDATA_PLUGIN_PROC_H */
